Destinations = Destinations or {}
Destinations.savedVarsInitialized = false
