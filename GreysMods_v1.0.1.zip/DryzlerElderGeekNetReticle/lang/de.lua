SafeAddString(SI_DEG_RETICLE_OPTS_MODE_CIRCLE_HEADER, "Fadenkreuz-Modus: Kreis")
SafeAddString(SI_DEG_RETICLE_OPTS_MODE_SQUARE_HEADER, "Fadenkreuz-Modus: Quadrat")
SafeAddString(SI_DEG_RETICLE_OPTS_MODE_DOT_HEADER, "Fadenkreuz-Modus: Punkt")
SafeAddString(SI_DEG_RETICLE_OPTS_MODE_RULE_HEADER, "Fadenkreuz-Modus: Linien / Kreuz")

SafeAddString(SI_DEG_RETICLE_OPTS_ROTATE, "Fadenkreuz drehen (90°)")

SafeAddString(SI_DEG_RETICLE_OPTS_HRULE, "Horizontale Linie")
SafeAddString(SI_DEG_RETICLE_OPTS_VRULE, "Vertikale Linie")

SafeAddString(SI_DEG_RETICLE_MOTD, "Neuer Fadenkreiz-Modus: KREUZ (kann in den Einstellungen aktiviert werden)")