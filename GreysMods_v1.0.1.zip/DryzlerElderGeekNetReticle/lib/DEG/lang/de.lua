DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_SETTINGS_THIS_CHAR', "Einstellungen für den aktuellen Charakter")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_SETTINGS_ACCOUNTWIDE', "Einstellungen für den gesamten Account")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_SETTINGS_SCALE', "Größe / Skalierung")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_SETTINGS_OPACITY', "Deckkraft")

DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_AD1_HEADER', "|cEFEBBEEine Nachricht von|r |c3f95ffDryzler|r")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_LBL2_HEADER', "Danke dass du meine Addons benutzt. |cEFEBBE:)|r")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_LBL3_HEADER', "Siehr dir auch meine anderen Projekte an:")

DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_AD2_HEADER', "|cEFEBBEEine Nachricht von|r |c3f95ffDryzler|r")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_AD2_LBL2_HEADER', "Danke dass du meine Addons benutzt. |cEFEBBE:)|r")
DEGLIB_STRINGS_ADDSTRING('SI_DEG_SI_AD2_LBL3_HEADER', "Du suchst eine Gilde? Die Süßkringel warten auf Dich:")