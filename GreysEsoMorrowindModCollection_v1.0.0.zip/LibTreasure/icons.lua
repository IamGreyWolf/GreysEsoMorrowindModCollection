local LibTreasure = LibTreasure

LibTreasure.icons =
{
	[1] = "LibTreasure/Icons/x_red.dds",
	[2] = "LibTreasure/Icons/x_black.dds",
	[3] = "LibTreasure/Icons/map_black.dds",
	[4] = "LibTreasure/Icons/map_white.dds",
	[5] = "LibTreasure/Icons/hammerstrike.dds",
	[6] = "EsoUI/Art/Icons/justice_stolen_map_001.dds",
	[7] = "EsoUI/Art/Icons/quest_scroll_001.dds",
	[8] = "EsoUI/Art/Icons/scroll_001.dds",
	[9] = "EsoUI/Art/Icons/justice_stolen_unique_dwemer_puzzle_cube.dds",
	[10] = "EsoUI/Art/Icons/delivery_box_001.dds",
	[11] = "EsoUI/Art/Icons/justice_stolen_unique_jurgen_windcaller_plait.dds",
	[12] = "EsoUI/Art/Icons/justice_stolen_unique_shehai_essence_box.dds",
	[13] = "EsoUI/Art/Icons/crafting_accessory_sp_names_002.dds",
	[14] = "EsoUI/Art/Icons/crafting_accessory_sp_names_001.dds",
	[15] = "EsoUI/Art/Icons/collectable_memento_dawnshard.dds",
}