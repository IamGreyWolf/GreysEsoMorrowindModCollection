ZO_CreateStringId("SI_DEG_RETICLE_OPTS_MODE_CIRCLE_HEADER", "Reticle mode: Circle")
ZO_CreateStringId("SI_DEG_RETICLE_OPTS_MODE_SQUARE_HEADER", "Reticle mode: Square")
ZO_CreateStringId("SI_DEG_RETICLE_OPTS_MODE_DOT_HEADER", "Reticle mode: Dot")
ZO_CreateStringId("SI_DEG_RETICLE_OPTS_MODE_RULE_HEADER", "Reticle mode: Rules / Cross")

ZO_CreateStringId("SI_DEG_RETICLE_OPTS_ROTATE", "Rotate the Reticle (90°)")

ZO_CreateStringId("SI_DEG_RETICLE_OPTS_HRULE", "Horizontal rule")
ZO_CreateStringId("SI_DEG_RETICLE_OPTS_VRULE", "Vertical rule")


ZO_CreateStringId("SI_DEG_RETICLE_MOTD", "New reticle mode: CROSS (can be activated in the settings)")
