ZO_ChatWindowMinBar:SetAlpha(0)
