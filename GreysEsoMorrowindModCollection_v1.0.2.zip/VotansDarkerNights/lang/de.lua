﻿SafeAddString(SI_KEYBINDINGS_CATEGORY_VOTANS_DARKER_NIGHTS, "Dunklere Nächte", 0)
SafeAddString(SI_BINDING_NAME_VOTANS_TOGGLE_DARKER_NIGHT, "Dunklere Nächte umschalten", 0)

SafeAddString(SI_VOTANS_DARKER_NIGHT_DAYLIGHT_GAMMA, "Tageslicht Gamma", 0)
SafeAddString(SI_VOTANS_DARKER_NIGHT_DAYLIGHT_GAMMA_INFO, "Gamma während des Tages.", 0)
SafeAddString(SI_VOTANS_DARKER_NIGHT_FULL_MOON_GAMMA, "Vollmond Gamma", 0)
SafeAddString(SI_VOTANS_DARKER_NIGHT_FULL_MOON_GAMMA_INFO, "Gamma während der Vollmondnächte.", 0)
SafeAddString(SI_VOTANS_DARKER_NIGHT_NEW_MOON_GAMMA, "Neumond Gamma", 0)
SafeAddString(SI_VOTANS_DARKER_NIGHT_NEW_MOON_GAMMA_INFO, "Gamma während der Neumondnächte.", 0)
SafeAddString(SI_VOTANS_DARKER_NIGHT_DAYLIGHT_TRANSITION, "Tageslicht/Nacht Übergangsfaktor")
SafeAddString(SI_VOTANS_DARKER_NIGHT_DAYLIGHT_TRANSITION_TOOLTIP, "Je größer desto länger wird Tag- und kürzer Nachtgamma verwendet.\nDas hat kein Einfluss auf den im Spiel eingebauten Tagzyklus.")

SafeAddString(SI_VOTANS_DARKER_NIGHT_MODE, "Darker Night ist für die Zone \"<<T:2>>\" <<1[ausgeschaltet/eingeschaltet]>>.")
