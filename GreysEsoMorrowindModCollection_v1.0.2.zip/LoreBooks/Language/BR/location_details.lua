LoreBooks = LoreBooks or {}

LoreBooks.locationDetails = {
  [1] = "Town",
  [2] = GetString(SI_INSTANCEDISPLAYTYPE7),
  [3] = GetString(SI_INSTANCEDISPLAYTYPE6),
  [4] = "Underground",
  [5] = GetString(SI_INSTANCETYPE2),
  [6] = "Inside Inn",
  [7] = "Guest Room", -- 1
  [8] = "Attic Room", -- 2
  [9] = "Hidden Basement", -- 3
  [10] = "Bookshelf", -- 4
  [11] = "Leramil's Study",
  [12] = "Associate Zannon's Workshop",
  [13] = "Derelict Laboratory",
  [14] = "Hall Of Refined Techniques",
}
