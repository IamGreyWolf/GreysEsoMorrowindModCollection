# GreysEsoMods
A curated list of the ESO Mods I use.
This is a collection of Mods that help make the ESO experience more like the original Morrowind. Note that all of these go along with a series of settings for the game itself that makes the magic work.
