Destinations = Destinations or {}

-- Ability is the ability casted by the stone itself
Destinations.mundusStrings = {
  [13940] = GetAbilityDescription(60462), -- Boon: The Warrior
  [13943] = GetAbilityDescription(60550), -- Boon: The Mage
  [13974] = GetAbilityDescription(60594), -- Boon: The Serpent
  [13975] = GetAbilityDescription(60610), -- Boon: The Thief
  [13976] = GetAbilityDescription(60574), -- Boon: The Lady
  [13977] = GetAbilityDescription(60604), -- Boon: The Steed
  [13978] = GetAbilityDescription(60579), -- Boon: The Lord
  [13979] = GetAbilityDescription(60556), -- Boon: The Apprentice
  [13980] = GetAbilityDescription(60589), -- Boon: The Ritual
  [13981] = GetAbilityDescription(60584), -- Boon: The Lover
  [13982] = GetAbilityDescription(60569), -- Boon: The Atronach
  [13984] = GetAbilityDescription(60599), -- Boon: The Shadow
  [13985] = GetAbilityDescription(60554), -- Boon: The Tower
}